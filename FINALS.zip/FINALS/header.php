<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Final Project</title>
    <!-- Font Style-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa&family=Merriweather&family=The+Nautigal&display=swap" rel="stylesheet">
    <!-- End-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <style>
        .headerbg{
        background-color:#0f224a;
        padding: 10px
        }   
        .bot{
        padding: 0px 10px;
        }
        .b1 {
        font-family: 'Changa', sans-serif;
        font-size: 25px;
        padding: 10px 20px;
        border-radius: 20px;
        border: 0;
        color: white;
        font-weight: bold;
        background-color: #0f224a;
        }

        .b1:hover {
        outline: 2px solid white;
        }
        .title{
        color:white;
        margin-left:40px;
        font-size: 50px;
        font-family: 'Changa', sans-serif;
        }

        /* Product CSS */
        .container {
        margin-top: 50px;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        }

        .center-image {
        max-width: 100%;
        height: auto;
        border-radius: 20px;
        box-shadow: 0 0 30px rgba(0, 0, 0, .5);
        }
        .imgtxt{
        text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
        font-family: 'Changa', sans-serif;
        }
        .text-overlay {
        position: absolute;
        top: 70%;
        left:40%;
        transform: translate(-50%, -50%);
        text-align: center;
        color: white;
        }

        .text-overlay h1 {
        font-size: 40px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        /* Add media queries for responsiveness */
        @media (max-width: 1000px) {
        .text-overlay {
            width: 90%;
        }

        .text-overlay h1 {
            font-size: 20px;
        }
        }

        .store{
            text-align: center;
            font-size: 50px;
            padding: 10px;
            margin-top: 25px;
            margin-bottom:25px;
            margin-left: auto;
            margin-right: auto;
            font-family: 'Changa', sans-serif;
        }

        .ProductName{
            margin-top: 50px;
            margin-left: 5%;
            font-family: 'Changa', sans-serif;
        }
        .navbar-toggler{
            background-color: white;
            color: white;
        }
        .box{
            box-shadow: 0 0 20px rgba(0, 0, 0, .5);
            border-radius: 20px;
            margin-top: 20px;
            width: 300px;
            height: 400px;
        }
        .box:hover {
        /* Box shadow styles when hovering */
        box-shadow: 0 0 50px rgba(0, 0, 0, .5);
        }
        .coins{
            text-align: center;
            height: 150px;
            padding-top:10px;
            background-color: #DAEBE9 ;
            border-radius: 10px 10px 0px 0px;
        }
        .row {
            width: 100%;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }

        .row > div {
            padding-left: 100px;
        }
        .label{
            font-weight: bold;
            font-size: 20px;
            margin-left: 20px;
            margin-top: 20px;
            font-family: 'Changa', sans-serif;
        }
        .bonus{
            background-color: #E880B7;
            width: 220px;
            margin-top: 10px;
            margin-left: 10%;
            border-radius:5px;
            padding-left:5px;
            font-weight:bold;
            color:white;
        }
        .price{
        margin-left: 10%;
        margin-top: 10%;
        }
        .addtocart{
            margin-left: 30px;
            margin-top: 10%;
            padding:10px 20px 10px 20px;
            border-radius:50px;
            border:0px;
            color: white;
            font-weight:bold;
            background-image: linear-gradient(to right, #75CCA5 ,#1CC6BE);
            transition: background-color 0.3s ease;
        }
        .addtocart:hover {
            background-image: linear-gradient(to right, #529477, #14948E);
        }
        /* End Product CSS*/

        /* My Account CSS*/
        .test{
            padding: 40px; 
            border-radius: 8px; 
            margin-left: 750px;
            width: 100%;     
            margin-top: 50px; 
            font-family: 'Changa', sans-serif;
            font-size: 20px;
            box-shadow: 0 0 50px rgba(0, 0, 0, .5);

        }

        /* End My Account CSS */

	    /* Home CSS*/
        
        .carousel{
        padding-bottom: 130px;
        }
	    .img{
        font-family: 'Arial Black'; 
        margin-left: 1300px;
        text-align: center;
        }
        .lugia{
        padding-top: 50px;
        padding-bottom: 60px;
        font-family: 'Changa', sans-serif; 
        text-align: center;
        color: black; 
        }
        .ho-oh{
        padding-top: 50px;
        padding-bottom: 50px;
        font-family: 'Changa', sans-serif;  
        text-align: center;
        color: black; 
        }
        .tbl {
        border-collapse: collapse;
        width: 100%;
        padding: 10px;
        text-align: center;
        table-layout: fixed;
        }

        .tbl1 {
        margin-top: 2%;
        margin-bottom: 5%;
        max-width: 90%;
        height: auto;
        border-radius: 20px;
        box-shadow: 0 0 30px rgba(0, 0, 0, 0.5);
        }
        .events{
            text-align: center;
            font-size: 50px;
            padding: 10px;
            margin-top: 50px;
            margin-bottom:25px;
            margin-left: auto;
            margin-right: auto;
            font-family: 'Changa', sans-serif;
        }
        .fourth{
            margin-top: 5%;
            margin-left:-10%;
        }
        .imagepic{
            border-radius: 20px;
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.5);
        }
        .imagepic1{
            border-radius: 20px;
        }
        .txtt{
            margin-top:20px;
            font-size:35px;
            margin-bottom:20%;
            text-align:center;
            font-family: 'Changa', sans-serif;
        }
        .text-overlay1{
            position: absolute;
            top: 70%;
            left:25%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
        }
        .imgtxt1{
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
            font-family: 'Changa', sans-serif;
        }
         /* Add media queries for responsiveness */
         @media (max-width: 1000px) {
        .text-overlay1 {
            width: 90%;
        }

        .text-overlay1 h1 {
            font-size: 20px;
            margin-top: 10%;

        }
        }
        /* End Home CSS */

        .carttable{
            text-align: center;
            font-family: 'Changa', sans-serif;

        }
        .cartcontainer{
            margin-left: 10px;
        }
        .elem{
          text-align: center;
            font-size: 30px;
            width: 500px;
        }
        .elem1{
            border: 1px solid black;
            text-align: center;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class = "headerbg">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid"> <!--start of fluid cont-->
                <img src="https://seeklogo.com/images/P/pokemon-go-logo-6A54081537-seeklogo.com.png" width="200" height="100" class="d-inline-block align-top" alt="">
                <h1 class="title" href="#">Pokemon Go Kram Inc.</h1>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">  
                            <div class="bot">
                                <button class="b1" onclick="location.href='HomePage.php'" type="button">Home</button>
                            </div>
                        </li>

                        <li class="nav-item">
                            <div class="bot">
                                <button class="b1" onclick="location.href='Product.php'" type="button">Product</button>
                            </div>
                        </li>

                        <li class="nav-item">
                            <div class="bot">
                                <button class="b1" onclick="location.href='MyAccount.php'" type="button">My Account</button>
                            </div> 
                        </li>

                        <li class="nav-item">
                            <div class="bot">
                                <button class="b1" onclick="location.href='MyCart.php'" type="button">My Cart</button>
                            </div> 
                        </li>
                    </ul>
                </div>
            </div> <!-- cont fluid-->
        </nav>   
    </div>