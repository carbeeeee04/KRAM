

<?php

session_start();

require_once("header.php");
?>
<h1 class = "store">Poké Store</h1>

<div class="container">
  <img src="https://e0.pxfuel.com/wallpapers/353/781/desktop-wallpaper-the-weather-trio-in-pokemon-go-ultra-background-pokemon-go.jpg" class="center-image">
  <div class="text-overlay">
    <h1 class = "imgtxt">Get extra PokéCoins and<br>find exclusive deals at the<br>Pokémon Go Web Store!</h1>
  </div>
</div>


<h1 class = "ProductName">Poké Coins</h1>

<div class="row"> <!--1st Row Container-->  
    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 1 -->
        <div class = "box">
            <div class = coins>
                <img src="https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F070822898eca123f2f2dd9f1759f9734.png&w=256&q=75" width=120; height= auto;>
            </div>

            <div class="label">
                600 Poké Coins
            </div>

            <div class="bonus">
                100 STORE BONUS COINS
            </div>

            <div class="price">
                ₱249.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>
    
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 1 -->
        <div class = "box">
            <div class = coins>
                <img src="https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F28042bf667a908f5761e677f1cb62f1f.png&w=128&q=75" width=120; height= auto;>
            </div>

            <div class="label">
                1,300 Poké Coins
            </div>

            <div class="bonus">
                300 STORE BONUS COINS
            </div>

            <div class="price">
                ₱499.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 1 -->
        <div class = "box">
            <div class = coins>
                <img src="https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2Fdb583406b118ae8d86b525add9a4132d.png&w=384&q=75" width=120; height= auto;>
            </div>

            <div class="label">
                2,700 Poké Coins
            </div>

            <div class="bonus"> 
                500 STORE BONUS COINS
            </div>

            <div class="price">
                ₱999.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 1 -->
        <div class = "box">
            <div class = coins>
                <img src="https://store.pokemongolive.com/_next/image?url=https%3A%2F%2Fcdn3.xsolla.com%2Fimg%2Fmisc%2Fimages%2F8cabb613cc3703e052629e0bc7eec1af.png&w=128&q=75" width=120; height= auto;>
            </div>

            <div class="label">
                6,500 Poké Coins
            </div>

            <div class="bonus">
                1000 STORE BONUS COINS
            </div>

            <div class="price">
                ₱1990.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>

</div><!-- End of 1st Row Container--> 


<h1 class = "ProductName">Poké Balls</h1>

<div class="row"> <!--2nd Row Container-->  
    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 2 -->
        <div class = "box">
            <div class = coins>
                <img src="https://www.freepnglogos.com/uploads/pokeball-png/pokeball-alexa-style-blog-pokemon-inspired-charmander-daily-8.png" width=120; height= auto;>
            </div>

            <div class="label">
                20 Poké Balls
            </div>

            <div class="bonus">
                5 STORE BONUS BALLS
            </div>

            <div class="price">
                ₱49.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>
    
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 2 -->
        <div class = "box">
            <div class = coins>
                <img src="https://www.freepnglogos.com/uploads/pokeball-png/pokeball-alexa-style-blog-pokemon-inspired-charmander-daily-8.png" width=120; height= auto;>
            </div>

            <div class="label">
                120 Poké Balls
            </div>

            <div class="bonus">
                20 STORE BONUS BALLS
            </div>

            <div class="price">
                ₱249.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 2 -->
        <div class = "box">
            <div class = coins>
                <img src="https://www.freepnglogos.com/uploads/pokeball-png/pokeball-alexa-style-blog-pokemon-inspired-charmander-daily-8.png" width=120; height= auto;>
            </div>

            <div class="label">
                250 Poké Balls
            </div>

            <div class="bonus"> 
                50 STORE BONUS BALLS
            </div>

            <div class="price">
                ₱499.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 2 -->
        <div class = "box">
            <div class = coins>
                <img src="https://www.freepnglogos.com/uploads/pokeball-png/pokeball-alexa-style-blog-pokemon-inspired-charmander-daily-8.png" width=120; height= auto;>
            </div>

            <div class="label">
                600 Poké Balls
            </div>

            <div class="bonus">
                100 STORE BONUS BALLS
            </div>

            <div class="price">
                ₱999.00
            </div>
            
            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>

</div><!-- End of 2nd Row Container--> 


<h1 class = "ProductName">Poké Lures</h1>

<div class="row"> <!--3rd Row Container-->  
    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 3 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/1/1b/Lure_module1.png" width=120; height= auto;>
            </div>

            <div class="label">
                2 Poké Lures
            </div>

            <div class="bonus">
                1 STORE BONUS LURE
            </div>

            <div class="price">
                ₱99.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>
    
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 3 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/1/1b/Lure_module1.png" width=120; height= auto;>
            </div>

            <div class="label">
                10 Poké Lures
            </div>

            <div class="bonus">
                3 STORE BONUS LURES
            </div>

            <div class="price">
                ₱349.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 3 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/1/1b/Lure_module1.png" width=120; height= auto;>
            </div>

            <div class="label">
                25 Poké Lures
            </div>

            <div class="bonus"> 
                5 STORE BONUS LURES
            </div>

            <div class="price">
                ₱1199.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 3 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/1/1b/Lure_module1.png" width=120; height= auto;>
            </div>

            <div class="label">
                50 Poké Lures
            </div>

            <div class="bonus">
                10 STORE BONUS LURES
            </div>

            <div class="price">
                ₱2249.00
            </div>
            
            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>

</div><!-- End of 3rd Row Container--> 


<h1 class = "ProductName">Poké Incense</h1>

<div class="row"> <!--4th Row Container-->  
    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 4 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/8/86/Incense1.png" width=120; height= auto;>
            </div>

            <div class="label">
                2 Poké Incense
            </div>

            <div class="bonus">
                1 STORE BONUS INCENSE
            </div>

            <div class="price">
                ₱99.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>
    
        </div>
    </div>

    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 4 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/8/86/Incense1.png" width=120; height= auto;>
            </div>

            <div class="label">
                10 Poké Incense
            </div>

            <div class="bonus">
                3 STORE BONUS INCENSE
            </div>

            <div class="price">
                ₱349.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 4 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/8/86/Incense1.png" width=120; height= auto;>
            </div>

            <div class="label">
                25 Poké Incense
            </div>

            <div class="bonus"> 
                5 STORE BONUS INCENSE
            </div>

            <div class="price">
                ₱1199.00
            </div>

            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>


    <div class="col-lg-3 col-md-4 col-sm-12"> <!--1st Column-->  
        <!-- Product 4 -->
        <div class = "box">
            <div class = coins>
                <img src="https://pkmngotrading.com/mediawiki/images/8/86/Incense1.png" width=120; height= auto;>
            </div>

            <div class="label">
                50 Poké Incense
            </div>

            <div class="bonus">
                10 STORE BONUS INCENSE
            </div>

            <div class="price">
                ₱2249.00
            </div>
            
            <div>
                <a href="MyCart.php"> <button type="button" class = "addtocart">Add to Cart</button> </a> 
            </div>

        </div>
    </div>

</div><!-- End of 4th Row Container--> 


<?php
    $output = "";
    $output .= "
    <table class= 'table table-bordered table-striped'>
    <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>ID</th>
        <th>ID</th>
        <th>ID</th>
        <th>ID</th>
    </tr>

    ";
?>



<?php
require_once("footer.php");
?>