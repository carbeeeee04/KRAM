<?php
require_once("header.php");
?>

<h1 class = "store">My Cart</h1>



<?php
                $host = "localhost";
                $username = "root";
                $password = "";
                $database = "raprap";

                $con = new mysqli($host, $username, $password, $database);

                if($con->connect_error){
                    echo $con->connect_error;
                }

                $sql = "SELECT * FROM products";
                $cart = $con->query($sql) or die ($con->error);
                $row = $cart->fetch_assoc();

                ?>
                <div class="cartcontainer">
                    <div class="carttable">
                        <table>
                            <tr>
                                <th class = "elem">ID</th>
                                <th class = "elem">Product Name</th>
                                <th class = "elem">Amount</th>
                                <th class = "elem">Price</th>
                            </tr>
                            <?php
                            do {
                                echo '<tr>';
                                echo '<td class = "elem1">' . $row['ID'] . '</td>';
                                echo '<td class = "elem1">' . $row['Product_Name'] . '</td>';
                                echo '<td class = "elem1">' . $row['Amount'] . '</td>';
                                echo '<td class = "elem1">' . $row['Price'] . '</td>';
                                echo '</tr>';
                            } while ($row = $cart->fetch_assoc());
                            ?>
                        </table>
                    </div>
                </div>


<?php
require_once("footer.php");
?>