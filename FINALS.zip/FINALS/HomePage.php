<?php
require_once("header.php");
?>

<h1 class = "store">Home</h1>

<div id="carouselExample" class="carousel slide"> <!--carousel-->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images.alphacoders.com/956/956577.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images6.alphacoders.com/962/962550.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://wallpaperaccess.com/full/1360529.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="carousel"></span>
  </button>
</div>  <!--end of carousel-->

<div class="row g-0 bg-body-secondary position-relative">
  <img src="https://static-ssl.businessinsider.com/image/594addb5d084cc1d008b4586-899/screen%20shot%202017-06-21%20at%2045626%20pm.jp2" class="w-50" alt="...">
  <div class="col-md-6 p-4 ps-md-0">
  <div class="ho-oh"><h1>Ho-Oh (ホウオウ, Houou)</h1>
    <h2>is a Fire/Flying-type Legendary Pokémon introduced in Generation II. It is the Version Mascot for Pokémon Gold, along with its remake, Pokémon HeartGold. It also is the Trio Master of the Legendary Beasts and also called the Guardian of the skies.</h2>
  </div>
  <div class="lugia"><h1>LUGIA</h1>
    <h2>In Pokémon Gold and Silver and Pokémon HeartGold and SoulSilver, Lugia is a powerful legendary Pokémon that lives in a far-off location, and can be caught by the player. It is found in the depths of a sea cave located at the Whirl Islands, a group of isolated islands surrounded by whirlpools located off Route 41.</h2>
  </div>
</div>

 <h1 class = "events">Upcoming Events</h1>

 
  <div class="container"> 
      <img src="https://i.pinimg.com/originals/76/7d/b8/767db83fdd35fde6f3a22fd47060819d.png" class="center-image">
        <div class="text-overlay">
          <h1 class = "imgtxt">August 18-20! 26-27<br>Pokémon GO Fest 2023: Global.</h1>
        </div>  
  </div>

  
  <div class ="fourth">
    <div class="row"> <!--1st Row Container-->  
        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="imagepic">
            <img src="https://c4.wallpaperflare.com/wallpaper/235/462/551/pokemon-go-4k-high-resolution-mac-wallpaper-preview.jpg" width=100%; class = "imagepic1">
          </div>
              
                <h4 class="txtt">July 18, 2023<br>Rhyhorn with Double Catch Candy bonus.</h4>
              
        </div>  
        
        <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="imagepic"> 
          <img src="https://c4.wallpaperflare.com/wallpaper/763/182/334/pokemon-pokemon-go-ho-oh-pokemon-pokemon-go-hd-wallpaper-preview.jpg" width=100%; class = "imagepic1">
        </div>  
          
              <h4 class="txtt">July 25, 2023<br>Yungoos with Double Transfer Candy bonus</h4>
          
        </div>
    </div>

  </div>

  <img src="https://lh3.googleusercontent.com/RGShDyVofSODXIJ0eQ9umAID8tCw9KdqBFrtgCEdrxjJijG1qZBryfECP9IRV1MOJhCk4Za4VYB34DE-hnPesZNNVYMwgHKs9KrNue3LNJRJuw=e365-w1920" class="img-fluid" alt="...">

  <div class="text-overlay1">
    <h1 class = "imgtxt1">Catching Pokemon is one method of collecting them!<br>You can also obtain them by hatching Eggs<br>and exchanging them with other Trainers.</h1>
  </div>

<?php
require_once("footer.php");
?>