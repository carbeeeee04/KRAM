-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2023 at 08:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `raprap`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(200) NOT NULL,
  `Product_Name` varchar(200) NOT NULL,
  `Amount` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `Product_Name`, `Amount`, `Price`) VALUES
(1, '[600 Poké Coins]', '100 Store Bonus Coins', '₱249.00'),
(2, '1,300 Poké Coins', '300 STORE BONUS COINS', '₱499.00'),
(3, '2,700 Poké Coins', '500 STORE BONUS COINS', '₱999.00'),
(4, '6,500 Poké Coins', '1000 STORE BONUS COINS', '₱1990.00'),
(5, '20 Poké Balls', '5 STORE BONUS BALLS', '₱49.00\r\n'),
(6, '120 Poké Balls', '20 STORE BONUS BALLS', '₱249.00'),
(7, '250 Poké Balls', '50 STORE BONUS BALLS', '₱499.00'),
(8, '600 Poké Balls', '100 STORE BONUS BALLS', '₱999.00\r\n'),
(9, '2 Poké Lures', '1 STORE BONUS LURE', '₱99.00'),
(10, '10 Poké Lures', '3 STORE BONUS LURES', '₱349.00'),
(11, '25 Poké Lures', '5 STORE BONUS LURES', '₱1199.00\r\n'),
(12, '50 Poké Lures', '10 STORE BONUS LURES', '₱2249.00'),
(13, '2 Poké Incense', '1 STORE BONUS INCENSE', '₱99.00'),
(14, '10 Poké Incense', '3 STORE BONUS INCENSE', '₱349.00'),
(15, '25 Poké Incense', '5 STORE BONUS INCENSE', '₱1199.00'),
(16, '50 Poké Incense', '10 STORE BONUS INCENSE', '₱2249.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
