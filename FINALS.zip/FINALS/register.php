<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokemon KRAM</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

</head>
<style>
    .bg{
        background-color: #eeeeee;
    }
    
</style>
<body class="bg">

<div class="col col-md-3" style="margin: auto; margin-top:10px; padding: 30px;  border-radius: 8px; background-color: white">
    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        
        <div class="mb-3">
            <h3>My Personal Information<h3>
        </div>
        <div class="mb-3">
            <label for="fname">First Name</label>
            <input type="text" name="fname" id="fname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="mname">Middle Name</label>
            <input type="text" name="mname" id="mname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="lname">Last Name</label>
            <input type="text" name="lname" id="lname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="uname">Username</label>
            <input type="text" name="uname" id="uname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="pass">Password</label>
            <input type="password" name="pass" id="pass" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="cpass">Confirm Password</label>
            <input type="password" name="cpass" id="cpass" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="bday">Birthday</label>
            <input type="date" name="bday" id="bday" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="email">Email</label>
            <input type="text" name="email" id="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="cnum">Contact Number</label>
            <input type="text" name="cnum" id="cnum" class="form-control" required>
        </div>
        <div class="mb-3">
            <button  type="submit" name="submit" class="btn btn-primary">Submit</button>
            <a href="login.php" class="btn btn-secondary">I already have an Account</a>
        </div>
    </form>
</div>

<?php
    session_start();
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "raprap";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $fname = $_POST["fname"];
        $mname = $_POST["mname"];
        $lname = $_POST["lname"];
        $username = $_POST["uname"];
        $password = $_POST["pass"];
        $cpassword = $_POST["cpass"];
        $birthday = $_POST["bday"];
        $email = $_POST["email"];
        $number = $_POST["cnum"];
        $name = $fname." ".$mname." ".$lname;
        
        if($password != $cpassword)
        {
            echo "<table><tr><td>Password and confirm password are not the same</td></tr></table>";
        }
        else
        {
            $stmt = $conn->prepare("INSERT INTO raprap(USERNAME,NAME,EMAIL,PASS,BIRTHDAY,CONTACT) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param("ssssss",$username, $name, $email, $password, $birthday ,$number);
            $stmt->execute();
            $stmt->close();
            $conn->close();
            header("Location: login.php");
        echo "<table><tr><td>Registration successfull</td></tr></table>";
        }
    }
    ?>

<div style="padding-top:20px;">
<?php
    require_once("footer.php");
?>