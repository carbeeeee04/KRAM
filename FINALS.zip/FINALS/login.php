<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokemon KRAM</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Font Style-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa&family=Merriweather&family=The+Nautigal&display=swap" rel="stylesheet">
    <!-- End-->
</head>
<style>
    .bg{
        background-color: #eeeeee;
    }
    .testt{
        margin: auto;
        margin-top:200px;
        padding: 40px;
        border-radius: 8px; 
        margin-left: 750px;
        width: 100%;
        box-shadow: 0 0 50px rgba(0, 0, 0, .5);
        font-family: 'Changa', sans-serif;
    }
</style>
<body class="bg">

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "raprap";
        
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<div class="col col-md-3">
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <div class="testt   ">
            <div class="mb-3">
                <h3 style="width:100%; margin-left: 30%;">Log-in Form<h3>
            </div>

            <label class="mb-3" for="username" style="margin-left: 40%; font-family: 'Changa', sans-serif; ">Username:</label>
            <input style="margin-right:5px; margin-left: 26%;" type="text" id="username" name="username" required><br>

            <label class="mb-3" for="password" style="margin-right:5px; margin-left: 40%;">Password:</label>
            <input style="margin-right:5px; margin-left: 26%;" type="password" id="password" name="password" required><br>

            <div class="mb-2" style="padding-top:10px;">

                <button type="submit" name="submit" class="btn btn-primary" style="margin-left:40%;">Log in</button>

                    <div class="mb-3" style="padding-top:10px; margin-left:38.5%;">
                        <a href="?signup=true" class="btn btn-secondary">Sign Up</a>
                    </div>
            </div>
        </div>
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $check = true;
    $sql = "SELECT USERNAME, PASS FROM raprap";
    $result = $conn->query($sql);
    $numrows = $result->num_rows;
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        if ($username == $row["USERNAME"] && $password == $row["PASS"]) {
            $_SESSION["username"] = $username;
            $_SESSION["password"] = $password;
            $check = true;
            header("Location: HomePage.php");
        }
        else{
            $check = false;
        }
      }
    }
    if($check){
    }
    else{
        echo "<div class = 'mb-3'>Invalid Password or Username!!</div>";
    }
    }
    if (isset($_GET["signup"])) {
        header("Location: register.php");
        exit();
    }
    ?>
</div>
<div style="padding-top:233px;">
