<?php
session_start();

require_once("header.php");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "raprap";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT USERNAME, PASS, EMAIL, NAME, BIRTHDAY, CONTACT FROM raprap";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($_SESSION["username"] == $row["USERNAME"]) {
            $nam = $row["NAME"];
            $bday = $row["BIRTHDAY"];
            $cont = $row["CONTACT"];
            $mail = $row["EMAIL"];
        }
    }
}

$currentPassword = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $currentPassword = $_POST["cpass"];
    $newPassword = $_POST["npass"];
    $reenteredPassword = $_POST["rnpass"];

    if ($newPassword == $reenteredPassword) {
        $sql = "SELECT USERNAME, PASS FROM raprap WHERE USERNAME = '{$_SESSION["username"]}'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        if ($row && password_verify($currentPassword, $row["PASS"])) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $sql = "UPDATE raprap SET PASS = '$hashedPassword' WHERE USERNAME = '{$_SESSION["username"]}'";
            if ($conn->query($sql) === true) {
                echo "Password has been changed";
            } else {
                echo "Error updating password: " . $conn->error;
            }
        } else {
            echo "Current password is incorrect";
        }
    } else {
        echo "New password and confirm password do not match";
    }
}

if (isset($_GET["Logout"])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<h1 class="store">My Account</h1>
    <div class="col col-md-3">
        <div class = "test">
            <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                <div class="mb-3">
                    <h3>User Information Form</h3>
                </div>

                <div class="mb-3">
                    <label><b>Welcome </b><?php echo $nam; ?></label>
                </div>
                <div class="mb-3">
                    <label><b>Birthday: </b><?php echo $bday; ?></label>
                </div>
                <div class="mb-3">
                    <label><b>Contact Details</b></label>
                </div>
                <div class="mb-3">
                    <label><b>Email: </b><?php echo $mail; ?></label>
                </div>
                <div class="mb-3">
                    <label><b>Contact: </b><?php echo $cont; ?></label>
                </div>

                <a href="login.php?Logout=true" style="margin-left:82%" class="btn btn-danger">Logout</a>

                <div class="mb-3">
                    <label>RESET PASSWORD</label>
                </div>

                <div class="mb-3">
                    <label for="cpass">Enter Current Password</label>
                    <input type="password" name="cpass" id="cpass" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="npass">Enter New Password</label>
                    <input type="password" name="npass" id="npass" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="rnpass">Re-enter New Password</label>
                    <input type="password" name="rnpass" id="rnpass" class="form-control">
                </div>

                <div class="mb-3">
                    <button type="submit" name="submit" class="btn btn-primary">Reset Password</button>
                </div>

                    <div class="mb-3">
                        <label>
                            <?php
                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                echo $message;
                            }
                            ?>
                        </label>
                    </div>
            </form>
        </div>
</div>

<?php
$conn->close();
require_once("footer.php");
?>